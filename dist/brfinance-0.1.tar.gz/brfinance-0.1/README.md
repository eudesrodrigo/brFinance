# quantViewLib
Python lib to get financial data from Brazilian financial market
