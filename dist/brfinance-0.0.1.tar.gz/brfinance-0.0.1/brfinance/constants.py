REPORT_TYPE_MAPPER = {
    'ITR': 'EST_3',
    'DFP': 'EST_4'
}

BOOL_STRING_MAPPER = {
    True: "true",
    False: "false"
}

ENET_URL = "https://www.rad.cvm.gov.br/ENET/"
